$(document).ready(function() {
	$(".template__table_sortable table").tablesorter({sortList: [[0,0]]});
});
